//
//  CookMateTests.swift
//  CookMateTests
//
//  Created by KJSCE on 07/04/25.
//

import Testing
@testable import CookMate

struct CookMateTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
