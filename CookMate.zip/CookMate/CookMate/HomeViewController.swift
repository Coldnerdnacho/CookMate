import UIKit

struct Recipe {
    var name: String
    var associatedIngredients: [String]
    var cardView: UIView
}

class HomeViewController: UIViewController, UITextFieldDelegate {
    
    var assistant: HomeAssistant!
    
    @IBOutlet weak var Filter: UIBarButtonItem!
    @IBOutlet weak var dumplingsView: UIView!
    @IBOutlet weak var pastaView: UIView!
    @IBOutlet weak var biryaniView: UIView!
    @IBOutlet weak var vegetableSoupView: UIView!
    
    @IBOutlet weak var searchTextField: UITextField!  // connect your search bar UITextField here
    @IBOutlet weak var vegetableButton: UIButton!  // connect vegetable button
    @IBOutlet weak var fruitsButton: UIButton!     // connect fruits button
    @IBOutlet weak var cerealsButton: UIButton!    // connect cereals button
    
    var recipes: [Recipe] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        assistant = HomeAssistant(viewController: self)
        
        recipes = [
            Recipe(name: "Dumplings", associatedIngredients: ["cabbage", "carrot", "flour", "onion"], cardView: dumplingsView),
            Recipe(name: "Pasta", associatedIngredients: ["pasta", "cheese", "tomato", "onion"], cardView: pastaView),
            Recipe(name: "Biryani", associatedIngredients: ["rice", "chicken", "saffron", "onion", "carrot"], cardView: biryaniView),
            Recipe(name: "Vegetable Soup", associatedIngredients: ["broccoli", "carrot", "peas", "cabbage", "onion"], cardView: vegetableSoupView)
        ]
        
        searchTextField.delegate = self
        searchTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        
        // Button actions
        vegetableButton.addTarget(self, action: #selector(vegetableButtonPressed), for: .touchUpInside)
        fruitsButton.addTarget(self, action: #selector(fruitsButtonPressed), for: .touchUpInside)
        cerealsButton.addTarget(self, action: #selector(cerealsButtonPressed), for: .touchUpInside)
        
        print("HomeViewController Loaded Successfully!")
    }
    
    @IBAction func menuButtonTapped(_ sender: UIBarButtonItem) {
        let alertController = UIAlertController(title: nil, message: "Choose an option", preferredStyle: .actionSheet)
        
        let option1 = UIAlertAction(title: "Sort by popularity", style: .default) { _ in }
        let option2 = UIAlertAction(title: "Sort by calories", style: .default) { _ in }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alertController.addAction(option1)
        alertController.addAction(option2)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    // SEARCH Logic when typing
    @objc func textFieldDidChange(_ textField: UITextField) {
        guard let searchText = textField.text?.lowercased(), !searchText.isEmpty else {
            resetViews()  // Show all if empty
            return
        }
        
        for recipe in recipes {
            let matchName = recipe.name.lowercased().contains(searchText)
            let matchIngredient = recipe.associatedIngredients.contains { $0.lowercased().contains(searchText) }
            
            if matchName || matchIngredient {
                showView(recipe.cardView)
            } else {
                hideView(recipe.cardView)
            }
        }
    }
    
    // RESET: Show all recipe cards
    func resetViews() {
        for recipe in recipes {
            UIView.animate(withDuration: 0.3) {
                recipe.cardView.alpha = 1
                recipe.cardView.transform = .identity
            }
        }
    }
    
    // Small POP animation to show
    func showView(_ view: UIView) {
        UIView.animate(withDuration: 0.3) {
            view.alpha = 1
            view.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
        } completion: { _ in
            UIView.animate(withDuration: 0.2) {
                view.transform = .identity
            }
        }
    }
    
    // Fade out non-matching card
    func hideView(_ view: UIView) {
        UIView.animate(withDuration: 0.3) {
            view.alpha = 0.2
            view.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
        }
    }
    
    // BUTTONS: Category search (vegetables, fruits, cereals)
    @objc func vegetableButtonPressed() {
        animateButton(vegetableButton)  // Add animation to button
        searchByCategory(["cabbage", "carrot", "broccoli", "peas", "onion"])
    }
    
    @objc func fruitsButtonPressed() {
        animateButton(fruitsButton)  // Add animation to button
        searchByCategory(["tomato", "saffron"])  // loosely mapping fruits-ish
    }
    
    @objc func cerealsButtonPressed() {
        animateButton(cerealsButton)  // Add animation to button
        searchByCategory(["rice", "flour", "pasta"])
    }
    
    func searchByCategory(_ ingredients: [String]) {
        for recipe in recipes {
            let hasIngredient = recipe.associatedIngredients.contains { ingredients.contains($0.lowercased()) }
            
            if hasIngredient {
                showView(recipe.cardView)
            } else {
                hideView(recipe.cardView)
            }
        }
    }
    
    // BUTTON PRESS ANIMATION
    func animateButton(_ button: UIButton) {
        // Temporarily change button background color
        let originalColor = button.backgroundColor
        button.backgroundColor = UIColor.lightGray
        
        // Scale down and scale back to original size
        UIView.animate(withDuration: 0.1, animations: {
            button.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
        }) { _ in
            // After the press effect, return the button to its original scale and color
            UIView.animate(withDuration: 0.1) {
                button.transform = CGAffineTransform.identity
                button.backgroundColor = originalColor
            }
        }
    }
}

