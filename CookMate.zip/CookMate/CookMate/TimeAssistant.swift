//
//  TimeAssistant.swift
//  CookMate
//
//  Created by KJSCE on 22/04/25.
//

// TimerAssistant.swift

import UIKit

class TimerAssistant {
    
    weak var viewController: TimerControllerView?
    var timer: Timer?
    var isPaused: Bool = false
    
    var processes: [(name: String, duration: Int)] = [
        ("Boiling", 10),
        ("Chopping", 8),
        ("Sauteing", 12),
        ("Mixing", 5)
    ]
    
    var currentProcessIndex: Int = 0
    var remainingTime: Int = 0
    var isProcessCompleted: Bool = false

    init(viewController: TimerControllerView) {
        self.viewController = viewController
    }
    
    func startProcess() {
        if currentProcessIndex >= processes.count {
            viewController?.processLabel.text = "All Steps Done! 🎉"
            viewController?.timerLabel.text = "--:--"
            viewController?.startButton.setTitle("Restart", for: .normal)
            currentProcessIndex = 0
            return
        }
        
        let currentProcess = processes[currentProcessIndex]
        viewController?.processLabel.text = "Get Ready: \(currentProcess.name)"
        viewController?.timerLabel.text = "\(currentProcess.duration)s"
        remainingTime = currentProcess.duration
        isProcessCompleted = false
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            self?.startCountdown()
        }
    }
    
    func startCountdown() {
        isPaused = false
        viewController?.startButton.setTitle("Pause", for: .normal)
        
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            self?.tick()
        }
    }
    
    func tick() {
        guard !isPaused else { return }
        
        if remainingTime > 0 {
            remainingTime -= 1
            viewController?.timerLabel.text = "\(remainingTime)s"
            animateTimerLabel()
        } else {
            timer?.invalidate()
            isProcessCompleted = true
            viewController?.startButton.setTitle("Next Step", for: .normal)
            viewController?.processLabel.text = "\(processes[currentProcessIndex].name) Done ✅"
        }
    }
    
    func animateTimerLabel() {
        UIView.animate(withDuration: 0.2,
                       animations: {
            self.viewController?.timerLabel.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
        }, completion: { _ in
            UIView.animate(withDuration: 0.2) {
                self.viewController?.timerLabel.transform = .identity
            }
        })
    }
    
    func pauseOrResume() {
        if isPaused {
            isPaused = false
            viewController?.startButton.setTitle("Pause", for: .normal)
        } else {
            isPaused = true
            viewController?.startButton.setTitle("Resume", for: .normal)
        }
    }
    
    func moveToNextStep() {
        if isProcessCompleted {
            currentProcessIndex += 1
            startProcess()
        }
    }
    
    func restartAll() {
        currentProcessIndex = 0
        startProcess()
    }
}
