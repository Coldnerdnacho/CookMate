//
//  HomeAssistant.swift
//  CookMate
//
//  Created by KJSCE on 21/04/25.
//

import UIKit

class HomeAssistant {
    
    var viewController: UIViewController
    
    // Initialize with the view controller to present UI elements
    init(viewController: UIViewController) {
        self.viewController = viewController
    }
    
    // Example: Show an alert with a message
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Assistant Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        viewController.present(alert, animated: true, completion: nil)
    }
    
    // Example: Update a label's text (you pass the label as an argument)
    func updateLabel(label: UILabel, withText text: String) {
        label.text = text
    }
    
    // Example: Change background color of the view
    func changeBackgroundColor(to color: UIColor) {
        viewController.view.backgroundColor = color
    }
}

