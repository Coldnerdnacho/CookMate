//
//  LoginViewController.swift
//  CookMate
//
//  Created by KJSCE on 22/04/25.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

    var assistant: LoginAssistant!

    override func viewDidLoad() {
        super.viewDidLoad()
        assistant = LoginAssistant(viewController: self)
        self.navigationItem.backButtonTitle = "Sign In"
    }

    @IBAction func loginButtonTapped(_ sender: UIButton) {
        guard let email = emailTextField.text, !email.isEmpty,
              let password = passwordTextField.text, !password.isEmpty else {
            assistant.showError(message: "Please enter both email and password.")
            return
        }

        // Fake login check for now (you can replace with real logic later)
        if email == "test@example.com" && password == "password123" {
            assistant.showSuccessAndNavigate()
        } else {
            assistant.showError(message: "Invalid email or password.")
        }
    }
}
