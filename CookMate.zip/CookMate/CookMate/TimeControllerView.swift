import UIKit

class TimerControllerView: UIViewController {

    @IBOutlet weak var processLabel: UILabel!
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var startButton: UIButton!
    
    var assistant: TimerAssistant!

    override func viewDidLoad() {
        super.viewDidLoad()
        assistant = TimerAssistant(viewController: self)
        
        configureUI()
        assistant.startProcess()
    }
    
    func configureUI() {
        processLabel.font = UIFont.boldSystemFont(ofSize: 24)
        timerLabel.font = UIFont.monospacedDigitSystemFont(ofSize: 48, weight: .medium)
        timerLabel.textColor = UIColor.systemBlue
        startButton.layer.cornerRadius = 10
        startButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
    }
    
    @IBAction func startButtonTapped(_ sender: UIButton) {
        if assistant.isProcessCompleted {
            assistant.moveToNextStep()
        } else {
            if assistant.isPaused {
                assistant.pauseOrResume()
            } else {
                assistant.pauseOrResume()
            }
        }
    }
}
