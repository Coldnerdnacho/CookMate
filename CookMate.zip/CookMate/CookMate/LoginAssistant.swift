import UIKit

class LoginAssistant {
    
    weak var viewController: UIViewController?

    init(viewController: UIViewController) {
        self.viewController = viewController
    }

    func showError(message: String) {
        let alert = UIAlertController(title: "Login Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        viewController?.present(alert, animated: true)
    }

    func showSuccessAndNavigate() {
        let alert = UIAlertController(title: "Success", message: "Logged in successfully!", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Continue", style: .default, handler: { _ in
            self.navigateToHome()
        }))
        viewController?.present(alert, animated: true)
    }

    private func navigateToHome() {
        // Ensure the view controller is inside a navigation controller
        guard let navController = viewController?.navigationController else {
            showError(message: "Navigation controller not found!")
            return
        }
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        // Make sure the identifier matches the one set in the storyboard
        if let homeVC = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController {
            navController.pushViewController(homeVC, animated: true)
        } else {
            showError(message: "HomeViewController not found!")
        }
    }
}
